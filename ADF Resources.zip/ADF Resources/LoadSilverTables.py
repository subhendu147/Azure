# Databricks notebook source
"""
This notebook performs the following tasks:
1. Defines and retrieves several widgets for input from ADF
2. Based on the load_type, it performs specific operations:
   - If the load_type is "full", it truncates the specified table in the silver layer of the environment.
3. Execute the formatted ingestion query and store the result in a Spark DataFrame
4. Insert a log entry into the load_control_log table in the metadata database
"""

# COMMAND ----------

dbutils.widgets.text("database_name", "")
database_name = dbutils.widgets.get("database_name")

dbutils.widgets.text("environment_name", "")
env_name = dbutils.widgets.get("environment_name")

dbutils.widgets.text("table_name", "")
table_name = dbutils.widgets.get("table_name")

dbutils.widgets.text("ingestion_query", "")
ingestion_query = dbutils.widgets.get("ingestion_query")

dbutils.widgets.text("load_id", "")
load_id = dbutils.widgets.get("load_id")

dbutils.widgets.text("job_name", "")
job_name = dbutils.widgets.get("job_name")

dbutils.widgets.text("load_type", "")
load_type = dbutils.widgets.get("load_type")

# COMMAND ----------

# If the load type is "full", truncate the specified table in the silver layer of the environment
# If truncated, the data from the bronze table is loaded in its entirety
if load_type == "full":
    spark.sql(f"TRUNCATE TABLE {database_name}.{env_name}_silver.{table_name}")

# COMMAND ----------

# Format the ingestion query with the provided database name, environment name, table name, and load ID
ingestion_query = ingestion_query.format(database_name=database_name, env_name=env_name, table_name=table_name, load_id=load_id)

# Execute the formatted ingestion query and store the result in a Spark DataFrame
df = spark.sql(ingestion_query)

# Get the row count from the DataFrame by selecting the first row and first column
row_count = df.first()[0]

# COMMAND ----------

# Insert a log entry into the load_control_log table in the metadata database
# The log entry includes the load ID, job name, a description of the operation, 
# a message indicating the number of rows updated in the silver table, and the current timestamp
spark.sql(
    f"""INSERT INTO {database_name}.{env_name}_metadata.load_control_log 
        VALUES ("{load_id}", "{job_name}", "Silver Table Load", 
                "{row_count} rows in {env_name}_silver.{table_name} table are updated successfully", 
                current_timestamp())"""
)
