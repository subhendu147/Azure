# Databricks notebook source
"""
The below code is designed to handle the creation and population of a table using data from a CSV file stored in an Azure Data Lake Storage (ADLS) blob container. 

Initially, the code creates a new schema in an existing database and then proceeds to create a new table inside the created schema with defined structure.

Secondly, the code establishes a connection to the ADLS blob container and locates the specified CSV file. It then reads the data from the CSV file into a suitable data structure, such as a DataFrame. 

Finally, the data read from the CSV file is inserted into the created table in append mode, ensuring that any existing data in the table remains intact while the new data is added. 

This process facilitates efficient and organized data storage and retrieval, leveraging the capabilities of ADLS for scalable data management.
"""

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC -- Creates a new schema named <schema_name> under the database <databricks_name>
# MAGIC Create Schema <databricks_name>.<schema_name>;
# MAGIC
# MAGIC -- Creates a new table named voterslist under the schema <schema_name> in the database <databricks_name>
# MAGIC -- The table includes columns for Id, Name, Age, Occupation, and Vote_Eligibility with their respective data types
# MAGIC Create Table <databricks_name>.<schema_name>.voterslist (
# MAGIC       Id bigint, -- Unique identifier for each voter
# MAGIC       Name string, -- Name of the voter
# MAGIC       Age int, -- Age of the voter
# MAGIC       Occupation string, -- Occupation of the voter
# MAGIC       Vote_Eligibility boolean -- Indicates if the voter is eligible to vote
# MAGIC );

# COMMAND ----------

# This cell sets the access key for the Azure Data Lake Storage Gen2 account named '<storage_account_name>'.
# The access key provided is used for authentication purposes, allowing Spark to read from and write to the storage account.
spark.conf.set("fs.azure.account.key.<storage_account_name>.blob.core.windows.net","<access_key>")

# COMMAND ----------

# This cell retrieves and displays the current configuration value for the Azure storage account access key.
# It specifically fetches the key for the '<storage_account_name>.blob.core.windows.net' account.
# Useful for verifying that the key has been set correctly in the Spark configuration.
spark.conf.get ("fs.azure.account.key.<storage_account_name>.blob.core.windows.net")

# COMMAND ----------

# Import necessary data types from pyspark.sql.types for schema definition
from pyspark.sql.types import StructType, StructField, StringType, BooleanType, IntegerType, LongType

# Define the schema for the DataFrame to be read, specifying column names and data types
schema = StructType([
    StructField("Id", LongType(), False),  # Column 'Id' with data type Long (64-bit integer), not nullable
    StructField("Name", StringType(), False),  # Column 'Name' with data type String, not nullable
    StructField("Age", IntegerType(), False),  # Column 'Age' with data type Integer (32-bit integer), not nullable
    StructField("Occupation", StringType(), False),  # Column 'Occupation' with data type String, not nullable
    StructField("Vote_Eligibility", BooleanType(), False)  # Column 'Vote_Eligibility' with data type Boolean, not nullable
])

# COMMAND ----------

# Read a CSV file into a DataFrame using the defined schema.
# The file is located in an Azure Blob Storage container named '<container_name>'.
# The storage account is '<storage_account_name>'.
# The file path within the container is '<folder_name>/VotersList.csv'.
# The 'header' option is set to 'true' to indicate that the first row of the file contains column names.
# The schema is defined in the previous cell and includes columns for Id, Name, Age, Occupation, and Vote_Eligibility.
df = spark.read.schema(schema).option("header", "true").csv("wasbs://<container_name>@<storage_account_name>.blob.core.windows.net/<folder_name>/VotersList.csv")

# COMMAND ----------

# Display the DataFrame 'df' to view its content in a rich representation
display(df)

# COMMAND ----------

# This line of code appends the DataFrame 'df', to an existing table named 'voterslist'.
# The table is located within the '<schema_name>' schema of the '<databricks_name>' database.
# The 'append' mode is used, meaning new records from 'df' will be added to the 'voterslist' table without overwriting existing data.
df.write.mode("append").saveAsTable("<databricks_name>.<schema_name>.voterslist")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Retrieves all columns and rows from the voterslist table
# MAGIC select * from <databricks_name>.<schema_name>.voterslist
