# Databricks notebook source
"""
The below code is designed to create a CSV file and store it in an Azure Data Lake Storage (ADLS) blob container. 

Initially, the code displays the data present in a table which needs to be written to a CSV file in blob storage.

Secondly, the code establishes a connection to the ADLS storage account using access keys.

Finally, the data read from the table is written to a CSV file in the specified storage location in overwrite mode, ensuring that any existing data in the specified location is overwritten with the latest data. 
"""

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Retrieves all columns and rows from the voterslist table
# MAGIC select * from <databricks_name>.<schema_name>.voterslist

# COMMAND ----------

# This cell sets the access key for the Azure Data Lake Storage Gen2 account named '<storage_account_name>'.
# The access key provided is used for authentication purposes, allowing Spark to read from and write to the storage account.
spark.conf.set("fs.azure.account.key.<storage_account_name>.blob.core.windows.net","<access_key>")

# COMMAND ----------

# This cell retrieves and displays the current configuration value for the Azure storage account access key.
# It specifically fetches the key for the '<storage_account_name>.blob.core.windows.net' account.
# Useful for verifying that the key has been set correctly in the Spark configuration.
spark.conf.get ("fs.azure.account.key.<storage_account_name>.blob.core.windows.net")

# COMMAND ----------

# This cell executes a SQL query to select all records from the 'voterslist' table located in the '<schema_name>' schema within the '<databricks_name>' database and stores the result in a pyspark dataframe
df = spark.sql("select * from <databricks_name>.<schema_name>.voterslist")

# COMMAND ----------

# Coalesce the DataFrame to a single partition to ensure a single output file.
# Write the DataFrame to Azure Blob Storage in CSV format.
# Overwrite the existing file if it exists.
# Include the header in the CSV file.
df.coalesce(1).write.mode("overwrite").option("header", "true").csv("wasbs://<container_name>@<storage_account_name>.blob.core.windows.net/<folder_name>/VotersList.csv")
