# Databricks notebook source
"""
This notebook is designed to manage data ingestion processes in a Databricks environment. It includes the following key steps:
1. Creates text widgets and retrieves the values entered in these widgets for use in subsequent operations.
2. Conditional Table Truncation:
   - Checks the type of data load specified (full or incremental).
   - If the load type is "full", it truncates the specified table in the gold layer of the specified database and environment.
3. Execute the formatted ingestion query and store the result in a Spark DataFrame
4. Insert a log entry into the load_control_log table in the metadata schema of the specified database and environment
5. Retrieve the Azure Data Lake Storage (ADLS) access key from Databricks secrets using the specified secret scope and key name
6. Set the Azure Data Lake Storage (ADLS) access key configuration for the specified storage account
7. Query the metadata table to retrieve source and target file metadata for the specified job name
8. Archive the source files in ADLS into processed folder using the move operation
"""

# COMMAND ----------

# Create a text widget for the database name and retrieve its value
dbutils.widgets.text("database_name", "")
database_name = dbutils.widgets.get("database_name")

# Create a text widget for the environment name and retrieve its value
dbutils.widgets.text("environment_name", "")
env_name = dbutils.widgets.get("environment_name")

# Create a text widget for the table name and retrieve its value
dbutils.widgets.text("table_name", "")
table_name = dbutils.widgets.get("table_name")

# Create a text widget for the ingestion query and retrieve its value
dbutils.widgets.text("ingestion_query", "")
ingestion_query = dbutils.widgets.get("ingestion_query")

# Create a text widget for the load ID and retrieve its value
dbutils.widgets.text("load_id", "")
load_id = dbutils.widgets.get("load_id")

# Create a text widget for the job name and retrieve its value
dbutils.widgets.text("job_name", "")
job_name = dbutils.widgets.get("job_name")

# Create a text widget for the load type and retrieve its value
dbutils.widgets.text("load_type", "")
load_type = dbutils.widgets.get("load_type")

# Create a text widget for the storage account name and retrieve its value
dbutils.widgets.text("storage_account_name", "")
storage_account_name = dbutils.widgets.get("storage_account_name")

# COMMAND ----------

# Check if the load type is "full"
if load_type == "full":
    # If the load type is "full", truncate the specified table in the gold layer of the specified database and environment
    spark.sql(f"TRUNCATE TABLE {database_name}.{env_name}_gold.{table_name}")

# COMMAND ----------

# Format the ingestion query with the provided database name, environment name, table name, and load ID
ingestion_query = ingestion_query.format(database_name=database_name, env_name=env_name, table_name=table_name, load_id=load_id)

# Execute the formatted ingestion query and store the result in a Spark DataFrame
df = spark.sql(ingestion_query)

# Collect the first row of the DataFrame and extract the first column value to get the row count
row_count = df.collect()[0][0]

# COMMAND ----------

# Insert a log entry into the load_control_log table in the metadata schema of the specified database and environment
# The log entry includes the load ID, job name, a description of the operation, a message indicating the number of rows updated, and the current timestamp
spark.sql(
    f"""INSERT INTO {database_name}.{env_name}_metadata.load_control_log 
        VALUES ("{load_id}", "{job_name}", "Gold Table Load", 
                "{row_count} rows in {env_name}_gold.{table_name} table are updated successfully", 
                current_timestamp())"""
)

# COMMAND ----------

# Retrieve the Azure Data Lake Storage (ADLS) access key from Databricks secrets using the specified secret scope and key name
adls_access_key = dbutils.secrets.get('CleverStudiesSecretScope','ADLS-Access-Key')

# COMMAND ----------

# Set the Azure Data Lake Storage (ADLS) access key configuration for the specified storage account
# This allows Spark to authenticate and access the ADLS resources using the provided access key
spark.conf.set(f"fs.azure.account.key.{storage_account_name}.blob.core.windows.net", adls_access_key)

# COMMAND ----------

# Query the metadata table to retrieve source and target file metadata for the specified job name
# The metadata table is dynamically referenced using the provided database name and environment name
# The result is collected into a list of Row objects for further processing
metadata = spark.sql(f"""SELECT * from {database_name}.{env_name}_metadata.source_target_file_metadata where JobName = "{job_name}";""").collect()

# COMMAND ----------

# Archive the source files in ADLS into processed folder using the move operation
for row in metadata:
    # Extract the target container name from the current row
    container_name = row['TargetContainerName']
    
    # Extract the target file path from the current row
    file_path = row['TargetFilePath']
    
    # Extract the target file name from the current row
    file_name = row['TargetFileName']
    
    # Extract the archive target file path from the current row
    archive_file_path = row['ArchiveTargetFilePath']
    
    # Extract the archive target file name from the current row
    archive_file_name = row['ArchiveTargetFileName']
    
    # Move the file from the target location to the archive location within the same container
    # The 'False' parameter indicates that the move operation should not overwrite any existing files at the destination
    dbutils.fs.mv(
        f"wasbs://{container_name}@{storage_account_name}.blob.core.windows.net/{file_path}/{file_name}",
        f"wasbs://{container_name}@{storage_account_name}.blob.core.windows.net/{archive_file_path}/{load_id}_{archive_file_name}",
        False
    )
