# Databricks notebook source
"""
This notebook performs the following tasks:
1. Creates text widgets to capture user inputs for database name, environment name, and storage account name.
2. Retrieves the values entered in the text widgets.
3. Creates all the required tables as external tables for the sales analysis requirement in the specified ADLS location.
"""

# COMMAND ----------

# Create a text widget for the database name and retrieve its value
dbutils.widgets.text("database_name", "")
database_name = dbutils.widgets.get("database_name")

# Create a text widget for the environment name and retrieve its value
dbutils.widgets.text("environment_name", "")
env_name = dbutils.widgets.get("environment_name")

# Create a text widget for the storage account name and retrieve its value
dbutils.widgets.text("storage_account_name", "")
storage_account_name = dbutils.widgets.get("storage_account_name")

# COMMAND ----------

# Create or replace the source_metadata table in the specified database and environment.
# The table will store metadata related to data sources, including connection details and the ADLS name.
# The external table is created in the Azure Data Lake Storage (ADLS) specified by the location.

spark.sql(
    f"""CREATE OR REPLACE TABLE {database_name}.{env_name}_metadata.source_metadata (
    JobID INT,  -- Unique identifier for the job
    JobName VARCHAR(255),  -- Name of the job
    HostName VARCHAR(255),  -- Hostname of the data source
    Port INT,  -- Port number of the data source
    UserName VARCHAR(255),  -- Username for accessing the data source
    PasswordSecretName VARCHAR(255),  -- Secret name for the source password stored in the key vault
    ADLSName VARCHAR(255)  -- Name of the target Azure Data Lake Storage
    ) LOCATION "abfss://metadata@{storage_account_name}.dfs.core.windows.net/source_metadata";
"""
)

# COMMAND ----------

# Create or replace the source_target_file_metadata table in the specified database and environment.
# This table will store metadata related to the source and target files, including their paths, names, and other relevant details.
# The external table is created in the Azure Data Lake Storage (ADLS) specified by the storage account name.

spark.sql(f"""CREATE OR REPLACE TABLE {database_name}.{env_name}_metadata.source_target_file_metadata (
    JobID INT,  -- Unique identifier for the job
    JobName VARCHAR(255),  -- Name of the job
    SourceFilePath VARCHAR(255),  -- File path of the source data
    SourceFileName VARCHAR(255),  -- File name of the source data
    SourceFilePrefix VARCHAR(255),  -- Prefix for the source files
    TargetContainerName VARCHAR(255),  -- Name of the target container in ADLS
    TargetFilePath VARCHAR(255),  -- File path of the target file in ADLS
    TargetFileName VARCHAR(255),  -- Name of the target file in ADLS
    ArchiveSourceFilePath VARCHAR(255),  -- Path where the source files are to be archived
    ArchiveSourceFileName VARCHAR(255),  -- Name of the source files when being archived
    ArchiveTargetFilePath VARCHAR(255),  -- Path where the target files are to be archived
    ArchiveTargetFileName VARCHAR(255),  -- Name of the target files when being archived
    Header BOOLEAN,  -- Whether the first row is a header or not
    Delimiter VARCHAR(5)  -- Delimiter used in the file
    ) LOCATION "abfss://metadata@{storage_account_name}.dfs.core.windows.net/source_target_file_metadata";
""")

# COMMAND ----------

# Create or replace the table_load_metadata table in the specified database and environment.
# This table will store metadata related to the loading of tables at different stages (bronze, silver, gold).
# The table is created in the Azure Data Lake Storage (ADLS) specified by the storage account name.

spark.sql(
    f"""CREATE OR REPLACE TABLE {database_name}.{env_name}_metadata.table_load_metadata (
    JobID INT,  -- Unique identifier for the job, can be duplicate to accomodate different sub jobs
    JobName VARCHAR(255),  -- Name of the job
    LoadType VARCHAR(255),  -- Type of load (e.g., full, incremental)
    SubJobType VARCHAR(255),  -- Sub-type of the job (e.g., bronze load, silver load)
    BronzeTableName VARCHAR(255),  -- Name of the bronze table
    BronzeTableQuery STRING,  -- Query used to load the bronze table
    SilverTableName VARCHAR(255),  -- Name of the silver table
    SilverTableQuery STRING,  -- Query used to load the silver table
    GoldTableName VARCHAR(255),  -- Name of the gold table
    GoldTableQuery STRING,  -- Query used to load the gold table
    SourceFilePrefix VARCHAR(255),  -- Prefix for the source files
    ExecutionOrder INT  -- Order of execution for the job
    ) LOCATION "abfss://metadata@{storage_account_name}.dfs.core.windows.net/table_load_metadata";
"""
)

# COMMAND ----------

# Create or replace the load_control_log table in the specified database and environment.
# This table will store control log information related to various loads, including their types, values, and timestamps.
# The table is created in the Azure Data Lake Storage (ADLS) specified by the storage account name.

spark.sql(
    f"""CREATE OR REPLACE TABLE {database_name}.{env_name}_metadata.load_control_log (
    LoadID VARCHAR(255),  -- Unique identifier for the load
    JobName VARCHAR(255),  -- Name of the job associated with the load
    Type VARCHAR(255),  -- Type of control log entry (e.g., start, end, error)
    Value VARCHAR(255),  -- Value associated with the control log entry
    LoadTimestamp TIMESTAMP  -- Timestamp when the control log entry was recorded
    ) LOCATION "abfss://metadata@{storage_account_name}.dfs.core.windows.net/load_control_log";
"""
)

# COMMAND ----------

# Create or replace the audit_log table in the specified database and environment.
# This table will store audit log information related to various jobs, including their statuses, start and end times, and other relevant details.
# The table is created in the Azure Data Lake Storage (ADLS) specified by the storage account name.

spark.sql(
    f"""CREATE OR REPLACE TABLE {database_name}.{env_name}_metadata.audit_log (
    LoadID VARCHAR(255) PRIMARY KEY,  -- Unique identifier for the load, serves as the primary key
    JobID INT,  -- Unique identifier for the job
    JobName VARCHAR(255),  -- Name of the job
    Status VARCHAR(255),  -- Status of the job (e.g., success, failure)
    TriggerType VARCHAR(255),  -- Type of trigger that initiated the job (e.g., manual, scheduled)
    JobStart TIMESTAMP,  -- Timestamp when the job started
    JobEnd TIMESTAMP,  -- Timestamp when the job ended
    Duration VARCHAR(255),  -- Duration of the job in a human-readable format
    GoldTableName VARCHAR(255),  -- Name of the gold table associated with the job
    Parameters VARCHAR(255)  -- Parameters used for the job
    ) LOCATION "abfss://metadata@{storage_account_name}.dfs.core.windows.net/audit_log";
"""
)

# COMMAND ----------

# Create or replace the customers table in the specified database and environment.
# This table will store customer information, including their IDs, names, and countries.
# The table is created in the Azure Data Lake Storage (ADLS) specified by the storage account name.

spark.sql(
    f"""CREATE OR REPLACE TABLE {database_name}.{env_name}_bronze.customers (
    CustomerID INT PRIMARY KEY,  -- Unique identifier for the customer, serves as the primary key
    CustomerName VARCHAR(255),  -- Name of the customer
    Country VARCHAR(255)  -- Country of the customer
    ) Location "abfss://bronze@{storage_account_name}.dfs.core.windows.net/customers";
"""
)

# COMMAND ----------

# Create or replace the orders table in the specified database and environment.
# This table will store order information, including order IDs, customer IDs, order dates, and amounts.
# The table is created in the Azure Data Lake Storage (ADLS) specified by the storage account name.

spark.sql(
    f"""CREATE OR REPLACE TABLE {database_name}.{env_name}_bronze.orders (
    OrderID INT PRIMARY KEY,  -- Unique identifier for the order, serves as the primary key
    CustomerID INT,  -- Unique identifier for the customer who placed the order
    OrderDate DATE,  -- Date when the order was placed
    Amount DECIMAL(10, 2)  -- Total amount of the order in decimal format
    )  Location "abfss://bronze@{storage_account_name}.dfs.core.windows.net/orders";
"""
)

# COMMAND ----------

# Create or replace the products table in the specified database and environment.
# This table will store product information, including product IDs, names, and prices.
# The table is created in the Azure Data Lake Storage (ADLS) specified by the storage account name.

spark.sql(
    f"""CREATE OR REPLACE TABLE {database_name}.{env_name}_bronze.products (
    ProductID INT PRIMARY KEY,  -- Unique identifier for the product, serves as the primary key
    ProductName VARCHAR(255),  -- Name of the product
    Price DECIMAL(10, 2)  -- Price of the product in decimal format
    )  Location "abfss://bronze@{storage_account_name}.dfs.core.windows.net/products";
"""
)

# COMMAND ----------

# Create or replace the order_details table in the specified database and environment.
# This table will store detailed information about each order, including order detail IDs, order IDs, product IDs, and quantities.
# The table is created in the Azure Data Lake Storage (ADLS) specified by the storage account name.

spark.sql(
    f"""CREATE OR REPLACE TABLE {database_name}.{env_name}_bronze.order_details (
    OrderDetailID INT PRIMARY KEY,  -- Unique identifier for the order detail, serves as the primary key
    OrderID INT,  -- Unique identifier for the order, foreign key referencing orders table
    ProductID INT,  -- Unique identifier for the product, foreign key referencing products table
    Quantity INT  -- Quantity of the product ordered
    )  Location "abfss://bronze@{storage_account_name}.dfs.core.windows.net/order_details";
"""
)

# COMMAND ----------

# Create or replace the employees table in the specified database and environment.
# This table will store employee information, including employee IDs, names, and departments.
# The table is created in the Azure Data Lake Storage (ADLS) specified by the storage account name.

spark.sql(
    f"""CREATE OR REPLACE TABLE {database_name}.{env_name}_bronze.employees (
    EmployeeID INT PRIMARY KEY,  -- Unique identifier for the employee, serves as the primary key
    EmployeeName VARCHAR(255),  -- Name of the employee
    Department VARCHAR(255)  -- Department to which the employee belongs
    )  Location "abfss://bronze@{storage_account_name}.dfs.core.windows.net/employees";
"""
)

# COMMAND ----------

# Create or replace the departments table in the specified database and environment.
# This table will store department information, including department IDs and department names.
# The table is created in the Azure Data Lake Storage (ADLS) specified by the storage account name.

spark.sql(
    f"""CREATE OR REPLACE TABLE {database_name}.{env_name}_bronze.departments (
    DepartmentID INT PRIMARY KEY,  -- Unique identifier for the department, serves as the primary key
    DepartmentName VARCHAR(255)  -- Name of the department
    ) Location "abfss://bronze@{storage_account_name}.dfs.core.windows.net/departments";
"""
)

# COMMAND ----------

# Create or replace the customers_orders table in the specified database and environment.
# This table will store information about customer orders, including order IDs, customer IDs, customer names, countries, order dates, and amounts.
# The table is created in the Azure Data Lake Storage (ADLS) specified by the storage account name.

spark.sql(f"""CREATE OR REPLACE TABLE {database_name}.{env_name}_silver.customers_orders (
    OrderID INT PRIMARY KEY,  -- Unique identifier for the order, serves as the primary key
    CustomerID INT,  -- Unique identifier for the customer
    CustomerName VARCHAR(255),  -- Name of the customer
    Country VARCHAR(255),  -- Country of the customer
    OrderDate DATE,  -- Date when the order was placed
    Amount DECIMAL(10, 2),  -- Total amount of the order
    LoadID VARCHAR(255),  -- Identifier for the data load
    LoadTimestamp TIMESTAMP,  -- Timestamp when the data was loaded
    UpdateTimestamp TIMESTAMP  -- Timestamp when the data was last updated
    )  Location "abfss://silver@{storage_account_name}.dfs.core.windows.net/customers_orders";
""")

# COMMAND ----------

# Create or replace the orders_products table in the specified database and environment.
# This table will store detailed information about products in customer orders, including order detail IDs, order IDs, product IDs, product names, prices, quantities, total prices, order dates, customer IDs, load IDs, load timestamps, and update timestamps.
# The table is created in the Azure Data Lake Storage (ADLS) specified by the storage account name.

spark.sql(
    f"""CREATE OR REPLACE TABLE {database_name}.{env_name}_silver.orders_products (
    OrderDetailID INT PRIMARY KEY,  -- Unique identifier for the order detail, serves as the primary key
    OrderID INT,  -- Unique identifier for the order
    ProductID INT,  -- Unique identifier for the product
    ProductName VARCHAR(255),  -- Name of the product
    Price DECIMAL(10, 2),  -- Price of the product
    Quantity INT,  -- Quantity of the product ordered
    TotalPrice DECIMAL(10, 2),  -- Total price for the quantity of the product ordered
    OrderDate DATE,  -- Date when the order was placed
    CustomerID INT,  -- Unique identifier for the customer
    LoadID VARCHAR(255),  -- Identifier for the data load
    LoadTimestamp TIMESTAMP,  -- Timestamp when the data was loaded
    UpdateTimestamp TIMESTAMP  -- Timestamp when the data was last updated
) Location "abfss://silver@{storage_account_name}.dfs.core.windows.net/orders_products";
"""
)

# COMMAND ----------

# Create or replace the employees_departments table in the specified database and environment.
# This table will store information about employees and their respective departments, including employee IDs, employee names, department IDs, department names, load IDs, load timestamps, and update timestamps.
# The table is created in the Azure Data Lake Storage (ADLS) specified by the storage account name.

spark.sql(
    f"""CREATE OR REPLACE TABLE {database_name}.{env_name}_silver.employees_departments (
    EmployeeID INT PRIMARY KEY,  -- Unique identifier for the employee, serves as the primary key
    EmployeeName VARCHAR(255),  -- Name of the employee
    DepartmentID INT,  -- Unique identifier for the department
    DepartmentName VARCHAR(255),  -- Name of the department
    LoadID VARCHAR(255),  -- Identifier for the data load
    LoadTimestamp TIMESTAMP,  -- Timestamp when the data was loaded
    UpdateTimestamp TIMESTAMP  -- Timestamp when the data was last updated
) Location "abfss://silver@{storage_account_name}.dfs.core.windows.net/employees_departments";
"""
)

# COMMAND ----------

# Create or replace the sales_analysis table in the specified database and environment.
# This table will store detailed sales analysis information, including order IDs, order dates, customer IDs, customer names, countries, product details, total prices, employee IDs, employee names, department names, load IDs, load timestamps, and update timestamps.
# The table is created in the Azure Data Lake Storage (ADLS) specified by the storage account name.

spark.sql(
    f"""CREATE OR REPLACE TABLE {database_name}.{env_name}_gold.sales_analysis (
    OrderID INT PRIMARY KEY,  -- Unique identifier for the order, serves as the primary key
    OrderDate DATE,  -- Date when the order was placed
    CustomerID INT,  -- Unique identifier for the customer
    CustomerName VARCHAR(255),  -- Name of the customer
    Country VARCHAR(255),  -- Country of the customer
    ProductDetails ARRAY<STRUCT<`ProductID`:INT,`ProductName`:STRING,`Quantity`:INT>>,  -- Array of product details, each containing product ID, product name, and quantity
    TotalPrice INT,  -- Total price for the order
    EmployeeID INT,  -- Unique identifier for the employee handling the order
    EmployeeName VARCHAR(255),  -- Name of the employee handling the order
    DepartmentName VARCHAR(255),  -- Name of the department the employee belongs to
    LoadID VARCHAR(255),  -- Identifier for the data load
    LoadTimestamp TIMESTAMP,  -- Timestamp when the data was loaded
    UpdateTimestamp TIMESTAMP  -- Timestamp when the data was last updated
) Location "abfss://gold@{storage_account_name}.dfs.core.windows.net/sales_analysis";
"""
)
