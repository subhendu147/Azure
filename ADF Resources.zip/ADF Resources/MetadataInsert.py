# Databricks notebook source
"""
This notebook performs the following tasks:
1. Creates text widgets to capture user inputs for the database name and environment name.
2. Retrieves the values entered in the text widgets for further use.
3. Executes an SQL INSERT statement to add a record into the source_metadata table.
4. Insert multiple records into the source_target_file_metadata table within the specified database and environment.
5. Insert multiple records into the table_load_metadata table within the specified database and environment.
"""

# COMMAND ----------

# Create a text widget to capture the database name from the user input
dbutils.widgets.text("database_name", "")
# Retrieve the value entered in the database name widget
database_name = dbutils.widgets.get("database_name")

# Create a text widget to capture the environment name from the user input
dbutils.widgets.text("environment_name", "")
# Retrieve the value entered in the environment name widget
env_name = dbutils.widgets.get("environment_name")

# COMMAND ----------

# Insert a record into the source_metadata table within the specified database and environment.
# The table name is dynamically constructed using the database name and environment name provided by the user.
# The record inserted contains metadata information such as ID, analysis type, IP address, port, user, authentication method, and storage account name.
spark.sql(
    f"""INSERT INTO {database_name}.{env_name}_metadata.source_metadata VALUES 
    (1,"Sales_Analysis","<vm_ip_address>",<port>,"<username>","SFTP-Password","<storage_account_name>")
"""
)

# COMMAND ----------

# Insert multiple records into the source_target_file_metadata table within the specified database and environment.
# The table name is dynamically constructed using the database name and environment name provided by the user.
# Each record inserted contains metadata information for different files such as ID, analysis type, source path, source file name,
# source table name, source layer, target path, target file name, processed path, processed file name, archive path, archive file name,
# a flag indicating if the file is active, and the delimiter used in the file.
spark.sql(
    f"""INSERT INTO {database_name}.{env_name}_metadata.source_target_file_metadata VALUES 
    (1,"Sales_Analysis","sales_analysis/customers/","customers.csv","customers","landing","sales_analysis/customers/","customers.csv","sales_analysis/customers/processed/","customers.csv","sales_analysis/customers/processed/","customers.csv",True,","),
    (1,"Sales_Analysis","sales_analysis/orders/","orders.csv","orders","landing","sales_analysis/orders/","orders.csv","sales_analysis/orders/processed/","orders.csv","sales_analysis/orders/processed/","orders.csv",True,","),
    (1,"Sales_Analysis","sales_analysis/products/","products.csv","products","landing","sales_analysis/products/","products.csv","sales_analysis/products/processed/","products.csv","sales_analysis/products/processed/","products.csv",True,","),
    (1,"Sales_Analysis","sales_analysis/order_details/","order_details.csv","order_details","landing","sales_analysis/order_details/","order_details.csv","sales_analysis/order_details/processed/","order_details.csv","sales_analysis/order_details/processed/","order_details.csv",True,","),
    (1,"Sales_Analysis","sales_analysis/employees/","employees.csv","employees","landing","sales_analysis/employees/","employees.csv","sales_analysis/employees/processed/","employees.csv","sales_analysis/employees/processed/","employees.csv",True,","),
    (1,"Sales_Analysis","sales_analysis/departments/","departments.csv","departments","landing","sales_analysis/departments/","departments.csv","sales_analysis/departments/processed/","departments.csv","sales_analysis/departments/processed/","departments.csv",True,",")
"""
)

# COMMAND ----------

# Insert multiple records into the table_load_metadata table within the specified database and environment.
# The table name is dynamically constructed using the database name and environment name provided by the user.
# Each record inserted contains metadata information for different table loads such as ID, analysis type, load type, load name, table name, 
# and other relevant details for incremental and full loads.
spark.sql(
    f"""INSERT INTO {database_name}.{env_name}_metadata.table_load_metadata VALUES 
    (1,"Sales_Analysis","full","bronze_table_load","customers",null,null,null,null,null,"customers",1),
    (1,"Sales_Analysis","full","bronze_table_load","orders",null,null,null,null,null,"orders",1),
    (1,"Sales_Analysis","full","bronze_table_load","products",null,null,null,null,null,"products",1),
    (1,"Sales_Analysis","full","bronze_table_load","order_details",null,null,null,null,null,"order_details",1),
    (1,"Sales_Analysis","full","bronze_table_load","employees",null,null,null,null,null,"employees",1),
    (1,"Sales_Analysis","full","bronze_table_load","departments",null,null,null,null,null,"departments",1),
    (1,"Sales_Analysis","incremental","silver_table_load",null,null,"customers_orders","MERGE INTO 
        {{database_name}}.{{env_name}}_silver.{{table_name}} AS target 
    USING 
        (SELECT
            o.OrderID,
            c.CustomerID,
            c.CustomerName,
            c.Country,
            o.OrderDate,
            o.Amount
        FROM
            {{database_name}}.{{env_name}}_bronze.orders o
        INNER JOIN
            {{database_name}}.{{env_name}}_bronze.customers c 
        ON 
            o.CustomerID = c.CustomerID) AS source 
    ON 
        target.OrderID = source.OrderID 
    WHEN MATCHED THEN 
        UPDATE SET 
            target.CustomerID = source.CustomerID,
            target.CustomerName = source.CustomerName,
            target.Country = source.Country,
            target.OrderDate = source.OrderDate,
            target.Amount = source.Amount,
            target.LoadID = '{{load_id}}',
            target.UpdateTimestamp = CURRENT_TIMESTAMP()
    WHEN NOT MATCHED THEN
        INSERT (
            OrderID,
            CustomerID,
            CustomerName,
            Country,
            OrderDate,
            Amount,
            LoadID,
            LoadTimestamp,
            UpdateTimestamp
        )
        VALUES (
            source.OrderID,
            source.CustomerID,
            source.CustomerName,
            source.Country,
            source.OrderDate,
            source.Amount,
            '{{load_id}}',
            CURRENT_TIMESTAMP(),
            CURRENT_TIMESTAMP()
        )",null,null,null,2),
    (1,"Sales_Analysis","incremental","silver_table_load",null,null,"orders_products","MERGE INTO 
        {{database_name}}.{{env_name}}_silver.{{table_name}} AS target 
    USING 
        (SELECT
            od.OrderDetailID,
            o.OrderID,
            p.ProductID,
            p.ProductName,
            p.Price,
            od.Quantity,
            (od.Quantity * p.Price) AS TotalPrice,
            o.OrderDate,
            o.CustomerID
        FROM
            {{database_name}}.{{env_name}}_bronze.order_details od
        INNER JOIN
            {{database_name}}.{{env_name}}_bronze.orders o 
        ON 
            od.OrderID = o.OrderID
        INNER JOIN
            {{database_name}}.{{env_name}}_bronze.products p 
        ON 
            od.ProductID = p.ProductID) as source
    ON
        target.OrderDetailID = source.OrderDetailID
    WHEN MATCHED THEN 
        UPDATE SET 
            target.OrderID = source.OrderID,
            target.ProductID = source.ProductID,
            target.ProductName = source.ProductName,
            target.Price = source.Price,
            target.Quantity = source.Quantity,
            target.TotalPrice = source.TotalPrice,
            target.OrderDate = source.OrderDate,
            target.CustomerID = source.CustomerID,
            target.LoadID = '{{load_id}}',
            target.UpdateTimestamp = CURRENT_TIMESTAMP()
    WHEN NOT MATCHED THEN
        INSERT (
            OrderDetailID,
            OrderID,
            ProductID,
            ProductName,
            Price,
            Quantity,
            TotalPrice,
            OrderDate,
            CustomerID,
            LoadID,
            LoadTimestamp,
            UpdateTimestamp
        )
        VALUES (
            source.OrderDetailID,
            source.OrderID,
            source.ProductID,
            source.ProductName,
            source.Price,
            source.Quantity,
            source.TotalPrice,
            source.OrderDate,
            source.CustomerID,
            '{{load_id}}',
            CURRENT_TIMESTAMP(),
            CURRENT_TIMESTAMP()
        )",null,null,null,2),
    (1,"Sales_Analysis","incremental","silver_table_load",null,null,"employees_departments","MERGE INTO 
        {{database_name}}.{{env_name}}_silver.{{table_name}} AS target 
    USING 
        (SELECT
            e.EmployeeID,
            e.EmployeeName,
            d.DepartmentID,
            d.DepartmentName
        FROM
            {{database_name}}.{{env_name}}_bronze.employees e
        INNER JOIN
            {{database_name}}.{{env_name}}_bronze.departments d 
        ON 
            e.Department = d.DepartmentName) AS source
    ON
        target.EmployeeID = source.EmployeeID
    WHEN MATCHED THEN 
        UPDATE SET 
            target.EmployeeName = source.EmployeeName,
            target.DepartmentID = source.DepartmentID,
            target.DepartmentName = source.DepartmentName,
            target.LoadID = '{{load_id}}',
            target.UpdateTimestamp = CURRENT_TIMESTAMP()
    WHEN NOT MATCHED THEN
        INSERT (
            EmployeeID,
            EmployeeName,
            DepartmentID,
            DepartmentName,
            LoadID,
            LoadTimestamp,
            UpdateTimestamp
        )
        VALUES (
            source.EmployeeID,
            source.EmployeeName,
            source.DepartmentID,
            source.DepartmentName,
            '{{load_id}}',
            CURRENT_TIMESTAMP(),
            CURRENT_TIMESTAMP()
        )",null,null,null,2),
    (1,"Sales_Analysis","incremental","gold_table_load",null,null,null,null,"sales_analysis","MERGE INTO 
        {{database_name}}.{{env_name}}_gold.{{table_name}} AS target
        USING (
            SELECT
                so.OrderID,
                so.OrderDate,
                so.CustomerID,
                so.CustomerName,
                so.Country,
                ARRAY_AGG(NAMED_STRUCT('ProductID', sp.ProductID, 'ProductName', sp.ProductName, 'Quantity', sp.Quantity)) ProductDetails,
                sum(sp.TotalPrice) TotalPrice,
                ed.EmployeeID,
                ed.EmployeeName,
                ed.DepartmentName
            FROM
                {{database_name}}.{{env_name}}_silver.customers_orders so
            INNER JOIN
                {{database_name}}.{{env_name}}_silver.orders_products sp 
            ON 
                so.OrderID = sp.OrderID
            INNER JOIN
                {{database_name}}.{{env_name}}_silver.employees_departments ed 
            ON 
                so.CustomerID = ed.EmployeeID
            GROUP BY
                so.OrderID,
                so.OrderDate,
                so.CustomerID,
                so.CustomerName,
                so.Country,
                ed.EmployeeID,
                ed.EmployeeName,
                ed.DepartmentName
        ) AS source
        ON 
            target.OrderID = source.OrderID
        WHEN MATCHED THEN
            UPDATE SET 
                target.OrderDate = source.OrderDate,
                target.CustomerID = source.CustomerID,
                target.CustomerName = source.CustomerName,
                target.Country = source.Country,
                target.ProductDetails = source.ProductDetails,
                target.TotalPrice = source.TotalPrice,
                target.EmployeeID = source.EmployeeID,
                target.EmployeeName = source.EmployeeName,
                target.DepartmentName = source.DepartmentName,
                target.LoadID = '{{load_id}}',
                target.UpdateTimestamp = CURRENT_TIMESTAMP()
        WHEN NOT MATCHED THEN
            INSERT (
                OrderID, 
                OrderDate, 
                CustomerID, 
                CustomerName, 
                Country, 
                ProductDetails,
                TotalPrice, 
                EmployeeID, 
                EmployeeName, 
                DepartmentName,
                LoadID,
                LoadTimestamp,
                UpdateTimestamp
            )
            VALUES (
                source.OrderID, 
                source.OrderDate, 
                source.CustomerID, 
                source.CustomerName, 
                source.Country, 
                source.ProductDetails,
                source.TotalPrice, 
                source.EmployeeID, 
                source.EmployeeName, 
                source.DepartmentName,
                '{{load_id}}',
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP()
            );",null,3)
"""
)
