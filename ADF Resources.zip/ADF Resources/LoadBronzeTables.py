# Databricks notebook source
"""
This notebook performs the following tasks:
1. Sets up widgets to capture user inputs for various parameters such as database name, environment name, storage account name, container name, file path, file name, table name, load ID, and job name.
2. Retrieves the values of these parameters from the widgets.
3. Fetches the ADLS access key from a secret scope to enable secure access to Azure Data Lake Storage.
4. Set the Azure Data Lake Storage (ADLS) access key in the Spark configuration using the key fetched before.
5. Read a CSV file from Azure Blob Storage into a Spark DataFrame
6. Write the DataFrame to a table in the specified database and environment
7. Insert a log entry into the load_control_log table in the specified database and environment
"""

# COMMAND ----------

# Create a text widget for the database name and retrieve its value
dbutils.widgets.text("database_name", "")
database_name = dbutils.widgets.get("database_name")

# Create a text widget for the environment name and retrieve its value
dbutils.widgets.text("environment_name", "")
env_name = dbutils.widgets.get("environment_name")

# Create a text widget for the storage account name and retrieve its value
dbutils.widgets.text("storage_account_name", "")
storage_account_name = dbutils.widgets.get("storage_account_name")

# Create a text widget for the container name and retrieve its value
dbutils.widgets.text("container_name", "")
container_name = dbutils.widgets.get("container_name")

# Create a text widget for the file path and retrieve its value
dbutils.widgets.text("file_path", "")
file_path = dbutils.widgets.get("file_path")

# Create a text widget for the file name and retrieve its value
dbutils.widgets.text("file_name", "")
file_name = dbutils.widgets.get("file_name")

# Create a text widget for the table name and retrieve its value
dbutils.widgets.text("table_name", "")
table_name = dbutils.widgets.get("table_name")

# Create a text widget for the load ID and retrieve its value
dbutils.widgets.text("load_id", "")
load_id = dbutils.widgets.get("load_id")

# Create a text widget for the job name and retrieve its value
dbutils.widgets.text("job_name", "")
job_name = dbutils.widgets.get("job_name")

# COMMAND ----------

# Retrieve the Azure Data Lake Storage (ADLS) access key from Databricks secrets
# The secret is stored in the 'CleverStudiesSecretScope' secret scope with the key 'ADLS-Access-Key'
adls_access_key = dbutils.secrets.get('CleverStudiesSecretScope','ADLS-Access-Key')

# COMMAND ----------

# Set the Azure Data Lake Storage (ADLS) access key in the Spark configuration
# This allows Spark to authenticate and access the specified storage account
spark.conf.set(f"fs.azure.account.key.{storage_account_name}.blob.core.windows.net", adls_access_key)

# COMMAND ----------

# Read a CSV file from Azure Blob Storage into a Spark DataFrame
# - The 'header' option is set to 'true' to use the first row as column names
# - The 'inferSchema' option is set to 'true' to automatically infer data types of columns
df = spark.read.option("header", "true").option("inferSchema", "true").csv(f"wasbs://{container_name}@{storage_account_name}.blob.core.windows.net/{file_path}/{file_name}")

# Count the number of rows in the DataFrame
row_count = df.count()

# COMMAND ----------

from pyspark.sql.functions import col

# Check if the table name is 'products'
# If true, cast the 'Price' column to Decimal type with precision 10 and scale 2
if table_name == "products":
    df = df.withColumn('Price', col('Price').cast('Decimal(10, 2)'))

# Check if the table name is 'orders'
# If true, cast the 'Amount' column to Decimal type with precision 10 and scale 2
if table_name == "orders":
    df = df.withColumn('Amount', col('Amount').cast('Decimal(10, 2)'))

# COMMAND ----------

# Write the DataFrame to a table in the specified database and environment
# - The 'mode' option is set to 'overwrite' to replace the existing table if it exists
# - The 'mergeSchema' option is set to 'true' to merge the schema of the DataFrame with the schema of the existing table
df.write.mode("overwrite").option("mergeSchema", "true").saveAsTable(f"{database_name}.{env_name}_bronze.{table_name}")

# COMMAND ----------

# Insert a log entry into the load_control_log table in the specified database and environment
# - The log entry includes the load_id, job_name, a description of the action, the table name, the number of rows loaded, and the current timestamp
# - The description indicates that the bronze table has been successfully loaded with the specified number of rows
spark.sql(
    f"""INSERT INTO {database_name}.{env_name}_metadata.load_control_log 
        VALUES ("{load_id}", "{job_name}", "Bronze Table Load", 
                "{env_name}_bronze.{table_name} table loaded with {row_count} rows successfully", 
                current_timestamp())"""
)
