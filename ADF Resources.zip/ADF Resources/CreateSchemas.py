# Databricks notebook source
"""
This notebook performs the following tasks:
1. Creates widgets to capture user inputs for environment name and database name.
2. Retrieves the values of the environment name and database name from the widgets.
3. Creates a new schema in the specified database using the provided environment name as a suffix.
"""

# COMMAND ----------

# Create a text widget for capturing the environment name from the user
dbutils.widgets.text("environment_name","")
# Retrieve the value of the environment name from the widget
env_name = dbutils.widgets.get("environment_name")

# Create a text widget for capturing the database name from the user
dbutils.widgets.text("database_name","")
# Retrieve the value of the database name from the widget
database_name = dbutils.widgets.get("database_name")

# COMMAND ----------

# Create a new schema in the specified database with the suffix '_metadata' using the provided environment name
spark.sql(f"Create schema {database_name}.{env_name}_metadata")

# COMMAND ----------

# Create a new schema in the specified database with the suffix '_bronze' using the provided environment name
spark.sql(f"Create schema {database_name}.{env_name}_bronze")

# COMMAND ----------

# Create a new schema in the specified database with the suffix '_silver' using the provided environment name
spark.sql(f"Create schema {database_name}.{env_name}_silver")

# COMMAND ----------

# Create a new schema in the specified database with the suffix '_gold' using the provided environment name
spark.sql(f"Create schema {database_name}.{env_name}_gold")
